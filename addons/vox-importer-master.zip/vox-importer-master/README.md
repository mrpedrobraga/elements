# vox-importer
A Godot plugin to import MagicaVoxel .vox files as meshes.

This is an adaptation of MagicaVoxelImporter by Scayze (https://github.com/scayze/MagicaVoxel-Importer)

This works with Godot 3.1 and includes import scaling option and XZ centering based on the MagicaVoxel vox resolution.
